package com.cts.hms.entity;

public class Route {
	private Long id;
	private String source;
	private String destination;
	private Integer minutes;
	public Route() {}
	public Route(Long id, String source, String destination, Integer minutes) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.minutes = minutes;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Integer getMinutes() {
		return minutes;
	}
	public void setMinutes(Integer minutes) {
		this.minutes = minutes;
	}
	@Override
	public String toString() {
		return "Route [id=" + id + ", source=" + source + ", destination=" + destination + ", minutes=" + minutes + "]";
	}
	
}
