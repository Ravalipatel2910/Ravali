package com.cts.hms.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cts.hms.entity.Schedule;

@Repository
public interface ScheduleDao {

	int create(Schedule schedule);

	List<Schedule> read();

	Schedule read(Long id);

	int update(Schedule schedule);

	int delete(Long id);

	List<Schedule> findScheduleBySourceDestination(String source, String destination);
}