package com.cts.hms.controller;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hms.entity.Schedule;
import com.cts.hms.service.ScheduleService;

@RestController
@CrossOrigin(origins = {"*"})
public class ScheduleController {
	@Autowired
	private ScheduleService ss;
	@PostMapping("/schedule")
	public int addSchedule(@RequestBody Schedule schedule)
	{
		schedule.setId(generateScheduleId());
		return ss.create(schedule);
	}
	
	@PostMapping("/schedule/repeat")
	public void repeat(@RequestBody Schedule schedule)
	{
		System.out.println("To repeat "+schedule.getRepeat()+" times");
		ZoneId defaultZoneId = ZoneId.systemDefault();
		int noOfDays=schedule.getRepeat();
		Date sdate = schedule.getSdate();
		LocalDate fromDate=Instant.ofEpochMilli(sdate.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
		for(int i=0;i<noOfDays;i++)
		{
			LocalDate temp=fromDate.plusDays(i);
			schedule.setSdate(Date.from(temp.atStartOfDay(defaultZoneId).toInstant()));
			addSchedule(schedule);
		}
	}
	
	@GetMapping("/schedule")
	public List<Schedule> getAllSchedules()
	{
		return ss.read();
	}
	
	@GetMapping("/schedule/{id}")
	public Schedule findScheduleById(@PathVariable Long id)
	{
		return ss.read(id);
	}
	
	@GetMapping("/schedule/{source}/{destination}")
	public List<Schedule> findScheduleBySourceDestination(@PathVariable String source, @PathVariable String destination)
	{
		return ss.findScheduleBySourceDestination(source, destination);
	}
	
	private Long generateScheduleId()
	{
		List<Schedule> schedules = getAllSchedules();
		Collections.sort(schedules,(a,b)->a.getId().compareTo(b.getId()));
		if(schedules.size()==0)
			return 1L;
		Schedule lastSchedule = schedules.get(schedules.size()-1);
		Long id=0L;
		if(lastSchedule!=null)
			id=lastSchedule.getId();
		id++;
		return id;
	}
	
	@PutMapping("/schedule")
	public int modifySchedule(@RequestBody Schedule schedule)
	{
		return ss.update(schedule);
	}
	
	@DeleteMapping("/schedule/{id}")
	public int removeSchedule(@PathVariable Long id)
	{
		return ss.delete(id);
	}
	
}
