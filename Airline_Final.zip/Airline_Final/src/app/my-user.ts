export class MyUser {
    id: string | undefined;
    username:string | undefined ;
    password:string | undefined;
    email: string | undefined;
    pnumber: string | undefined;
    dob: Date | undefined;
    gender: string| undefined;
}
