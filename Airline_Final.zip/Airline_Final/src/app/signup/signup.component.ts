import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: any;
  constructor(private fb: FormBuilder, private us: UserService) {
    this.signupForm = this.fb.group({
      id: ['', Validators.required],
      username: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(12)]],
      password: ['', [Validators.required, Validators.minLength(8)], Validators.maxLength(50)],
      confirmPassword: ['', Validators.required],
      email: ['', [Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$") ]],
      phonenumber: ['', [Validators.required, Validators.pattern("^[7-9]{1}[0-9]{9,11}$")]],
      dob: ['', Validators.required],
      gender: ['', Validators.required]
    },
      {
        validator: this.confirmedValidator('password', 'confirmPassword')
      });
  }

  // Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")
  // , Validators.pattern("^[0-9]{10,12}$")

  signup() {
    var myuser = this.signupForm.value;
    this.us.signup(myuser).subscribe(data => console.log(data));
  }

  confirmedValidator(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
      const control = formGroup.controls[controlName];
      const matchingControl = formGroup.controls[matchingControlName];
      if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
        return;
      }
      if (control.value !== matchingControl.value) {
        matchingControl.setErrors({ confirmedValidator: true });
      } else {
        matchingControl.setErrors(null);
      }
    }
  }

  ngOnInit(): void {
  }

  get f()
  {
    return this.signupForm.controls;
  }

}
