import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courosal',
  templateUrl: './courosal.component.html',
  styleUrls: ['./courosal.component.css']
})
export class CourosalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
