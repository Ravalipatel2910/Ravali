export class Booking {
    id: number = 0;
    schedule_id: number | undefined
    classtype: string | undefined
    passengers: number | undefined
    user_id: any | undefined
}
