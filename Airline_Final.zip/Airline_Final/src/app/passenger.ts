export class Passenger {
    id=0;
    booking_id: string | undefined
    salutation: string | undefined
    firstName: string | undefined
    lastName: string | undefined
    age: string | undefined
    gender: string | undefined
}
