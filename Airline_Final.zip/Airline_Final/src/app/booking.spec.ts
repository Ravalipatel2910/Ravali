import { Booking } from './booking';

describe('Booking', () => {
  it('should create an instance', () => {
    expect(new Booking()).toBeTruthy();
  });
});
