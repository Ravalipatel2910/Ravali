import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../booking.service';
import { PassengerService } from '../passenger.service';

@Component({
  selector: 'app-mytrip',
  templateUrl: './mytrip.component.html',
  styleUrls: ['./mytrip.component.css']
})
export class MytripComponent implements OnInit {
  booking_id: any;
  bookingHistory: any;
  currentBooking: any;
  constructor(private bs: BookingService, private ps: PassengerService, private router: Router) { }

  fnDeleteBooking() {
    alert("Your Booking for Booking id " + this.booking_id+ " Has been Cancelled")
    this.bs.deleteBookingDetails(this.booking_id).subscribe((data) => {
      console.log(data)
      if (data == 1) {
        this.ps.deleteByBookingId(this.booking_id).subscribe(data => console.log(data));
      }
      this.router.navigate(['/','mytrips'])
    });
  }


  ngOnInit(): void {
    console.log(localStorage.getItem("user"));
    if (localStorage.getItem("user") != null) {
      this.bs.getBookingDetailsByUserId(localStorage.getItem("userid")).subscribe(data => {
        console.log(data)
        this.bookingHistory = data;
      })
      this.bs.getBookingId().subscribe((data) => {
        console.log("Booking_id " + data);
        this.booking_id = data;
        this.bs.getCurrentBookingDetails(this.booking_id, localStorage.getItem("userid")).subscribe(data => {
          console.log(data);
          this.currentBooking = data;
        })
      });
    }
    else {
      alert("Please login to view your trips");
      this.router.navigate(['/', 'login']);
    }
  }
}
