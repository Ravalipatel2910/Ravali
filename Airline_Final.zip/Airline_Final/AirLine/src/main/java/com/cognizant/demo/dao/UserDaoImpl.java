package com.cognizant.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cognizant.demo.entity.Booking;
import com.cognizant.demo.entity.Userlogin;
import com.cognizant.demo.helper.UserRowMapping;


@Component
public class UserDaoImpl implements UserDao{

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int create(Userlogin user) {
		String sql = "insert into userdetails (id,username,password,email,pnumber,dob,gender,role) values(?,?,?,?,?,?,?,?)";
		return jdbcTemplate.update(sql, user.getId(), user.getUsername(), user.getPassword(), user.getEmail(),
				user.getPnumber(),user.getDob(),user.getGender(), "user");
	}

	public List<Userlogin> read() {
		String sql = "select * from userdetails";
		return jdbcTemplate.query(sql, new UserRowMapping());
	}

	public Userlogin read(Long id) {
		return jdbcTemplate.queryForObject("select * from userdetails where id=?", new UserRowMapping(), id);
	}

	public int modify(Userlogin user) {
		String sql = "update userdetails set password=?,email=?,pnumber=?,dob=?,gender=?,username=? where id=?";
		return jdbcTemplate.update(sql, user.getPassword(), user.getEmail(), user.getPnumber(),user.getDob(), user.getGender(),
				user.getUsername(), user.getId());
	}

	public int delete(Long id) {
		String sql = "delete from userdetails where id=?";
		return jdbcTemplate.update(sql, id);
	}
	
}