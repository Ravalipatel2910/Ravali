import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ScheduleService } from '../schedule.service';

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {
  scheduleForm:any;
  constructor(private fb:FormBuilder, private ss:ScheduleService) {
    this.scheduleForm=this.fb.group({
      id:[],
      route_id:[],
      flight_id:[],
      sdate:[],
      stime:[],
      repeat:[]
    });
   }

  ngOnInit(): void {
  }

  addSchedule()
  {
    console.log(this.scheduleForm.value);
    this.ss.addSchedule(this.scheduleForm.value).subscribe((data)=>{
      console.log(data);
    });
  }

  repeat()
  {
    //for 1 week
    console.log(this.scheduleForm.value);
    this.ss.repeat(this.scheduleForm.value).subscribe((data)=>{
      console.log(data);
    })
  }
}
