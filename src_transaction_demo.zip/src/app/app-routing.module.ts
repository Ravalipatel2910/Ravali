import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { OrderComponent } from './order/order.component';
import { ScheduleComponent } from './schedule/schedule.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'logout',component:LogoutComponent},
  {path:'order',component:OrderComponent},
  {path:'home',component:HomeComponent},
  {path:'cart',component:CartComponent},
  {path:'schedule',component:ScheduleComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
