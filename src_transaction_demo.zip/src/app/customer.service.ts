import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  url:string='http://localhost:8080/customer';
  constructor(private http:HttpClient) { }

  getStatus()
  {
    const myObservable=new Observable(observer=>{
      setTimeout(()=>{
        
        var customer=localStorage.getItem("customer");
        observer.next(customer);
      },100);
    });
    return myObservable;
  }

  getAllCustomers()
  {
    return this.http.get(this.url);
  }
  findCustomerByIdPassword(id:any, password:string)
  {
    return this.http.get(this.url+"/"+id+"/"+password);
  }
  signup(customer:any)
  {
    return this.http.post(this.url,customer);
  }
  modifyCustomer(customer:any)
  {
    return this.http.put(this.url,customer);
  }
  removeCustomer(id:any)
  {
    return this.http.delete(this.url+"/"+id);
  }
}
