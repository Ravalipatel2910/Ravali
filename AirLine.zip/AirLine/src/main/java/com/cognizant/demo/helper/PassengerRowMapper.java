
package com.cognizant.demo.helper;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cognizant.demo.entity.Passenger;

public class PassengerRowMapper implements RowMapper<Passenger>
{

	@Override
	public Passenger mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Passenger(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5));
	}

}

