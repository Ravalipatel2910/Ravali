package com.cognizant.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.demo.dao.PassengerDao;
import com.cognizant.demo.entity.Passenger;


@Service
public class PassengerService {
		@Autowired
		private PassengerDao pdao;
		
		public int create(Passenger passenger)
		{
			return pdao.create(passenger);
		}

		public List<Passenger> read()
		{
			return pdao.read();
		}

		public Passenger read(Long id)
		{
			return pdao.read(id);
		}

		public int update(Passenger passenger)
		{
			return pdao.update(passenger);
		}

		public int delete(Long id)
		{
			return pdao.delete(id);
		}
	

}

