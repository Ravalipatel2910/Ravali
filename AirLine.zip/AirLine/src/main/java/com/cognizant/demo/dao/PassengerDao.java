package com.cognizant.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cognizant.demo.entity.Passenger;

@Repository
public interface PassengerDao {

		int create(Passenger passenger);

		List<Passenger> read();

		Passenger read(Long id);

		int update(Passenger passenger);

		int delete(Long id);


}
