package com.cognizant.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cognizant.demo.entity.Passenger;
import com.cognizant.demo.helper.PassengerRowMapper;

@Component
public class PassengerDaoImpl implements PassengerDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int create(Passenger passenger) {
		return jdbcTemplate.update("INSERT INTO PASSENGER VALUES (?,?,?,?,?)", passenger.getid(),
				passenger.getBookingId(), passenger.getName(), passenger.getAge(), passenger.getGender());
	}

	@Override
	public List<Passenger> read() {
		return jdbcTemplate.query("SELECT * FROM PASSENGER", new PassengerRowMapper());
	}

	@Override
	public Passenger read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM PASSENGER WHERE id=?", new PassengerRowMapper(), id);
	}

	@Override
	public int update(Passenger passenger) {
		return jdbcTemplate.update("UPDATE PASSENGER SET bookingId=?, name=?, age=?, gender=? WHERE id=?",
				passenger.getBookingId(), passenger.getName(), passenger.getAge(), passenger.getGender(),
				passenger.getid());
	}

	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM PASSENGER WHERE id=?", id);
	}

}
