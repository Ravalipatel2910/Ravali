
package com.cognizant.demo.entity;

public class Booking {

	private Long id;
	private String flightBookingId;
	private Integer userId;

	public Booking(Long id, String flightBookingId, Integer userId) {
		super();
		this.id = id;
		this.flightBookingId = flightBookingId;
		this.userId = userId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFlightBookingId() {
		return flightBookingId;
	}

	public void setFlightBookingId(String flightBookingId) {
		this.flightBookingId = flightBookingId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "booking [id=" + id + ", flightBookingId=" + flightBookingId + ", userId=" + userId + "]";
	}

}
