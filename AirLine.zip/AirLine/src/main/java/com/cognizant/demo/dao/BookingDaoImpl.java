package  com.cognizant.demo.dao;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cognizant.demo.entity.Booking;
import com.cognizant.demo.helper.BookingRowMapper;
@Component
public class BookingDaoImpl implements BookingDao{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	
	@Override
	public int create(Booking booking ) {
		return jdbcTemplate.update("INSERT INTO BOOKING VALUES (?,?,?)", booking.getId(), booking.getFlightBookingId(), booking.getUserId());
	}
	
	
	@Override
	public List<Booking> read() {
		return jdbcTemplate.query("SELECT * FROM BOOKING", new BookingRowMapper());
	}
	
	
	@Override
	public Booking read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM BOOKING WHERE id=?", new BookingRowMapper(), id);
	}

	
	
	@Override
	public int update(Booking booking) {
		return jdbcTemplate.update("UPDATE BOOKING SET flightBookingId=?, userId=? WHERE id=?",  booking.getFlightBookingId(), booking.getUserId(), booking.getId());
	}
	
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM BOOKING WHERE id=?",id);
	}
	
}

