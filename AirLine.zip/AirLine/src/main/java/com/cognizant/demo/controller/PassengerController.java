package com.cognizant.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.demo.entity.Passenger;
import com.cognizant.demo.service.PassengerService;


@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class PassengerController {
		@Autowired
		private PassengerService  ps;
		
		@PostMapping("/passenger")
        public int signup(@RequestBody Passenger passenger)
     	{
			return ps.create(passenger);
		}
		@GetMapping("/passenger")
		public List<Passenger> getAllPassenger()
		{
			return ps.read();
		}
		@GetMapping("/passenger/{id}")
		public Passenger findCustomerById(@PathVariable Long id)
		{
			return ps.read(id);
		}
		@PutMapping("/passenger")
		public int modifyPassenger(@RequestBody Passenger passenger)
		{
			return ps.update(passenger);
		}
		@DeleteMapping("/passenger/{id}")
		public int removePassenger(@PathVariable Long id)
		{
			return ps.delete(id);
		}
	}

