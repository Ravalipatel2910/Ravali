import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ScheduleService } from '../schedule.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  flightId: any;
  bookingForm: any;
  date: any;
  constructor(private fb: FormBuilder, private router: Router, private ss: ScheduleService) {
    this.bookingForm = this.fb.group({
      flight_id: [],
      type: [],
      source: [],
      destination: [],
      sdate: [],
      returndate: [],
      noofpassengers: []
    })
  }

  ngOnInit(): void {
    this.flightId = localStorage.getItem("flight");
    this.ss.findScheduleById(this.flightId).subscribe((data) => {
      console.log(data)
      var flightObject = JSON.parse(JSON.stringify(data));
      this.bookingForm.patchValue(data);
      this.date = flightObject.sdate;
      // let latest_date = this.datepipe.transform(this.date, 'dd-MM-yyyy');






    });
  }

  fnBooking() {

    this.router.navigate(['/', 'passenger']);
  }
}
