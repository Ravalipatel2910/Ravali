import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MyUser } from '../my-user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm:any;
  constructor(private fb:FormBuilder, private us:UserService) { 
    this.signupForm=this.fb.group({
      id:[],
      username:[],
      password:[],
      confirmPassword:[],
      email:[],
      phonenumber:[],
      dob:[],
      gender:[]
    });
  }

  signup()
  {
    var myuser=this.signupForm.value;
    
    console.log(myuser);
    myuser.id=this.signupForm.controls['id'].value;
    myuser.username=this.signupForm.controls['username'].value;
    myuser.email=this.signupForm.controls['email'].value;
    myuser.password=this.signupForm.controls['password'].value;
    myuser.gender=this.signupForm.controls['gender'].value;
    myuser.pnumber=this.signupForm.controls['phonenumber'].value;
    myuser.dob=this.signupForm.controls['dob'].value;
    console.log(myuser);
    this.us.signup(myuser).subscribe(data=>console.log(data));  
  }
  ngOnInit(): void {
  }
 
}
