import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: any;
  str: any;
  role:any;
  username: any;
  constructor(private fb: FormBuilder, private us: UserService, private router: Router) {
    this.loginForm = this.fb.group({
      id: [],
      password: []
    });
  }

  ngOnInit(): void {
  }

  login() {
    var id = this.loginForm.controls['id'].value;
    var password = this.loginForm.controls['password'].value;
    this.us.login(id, password).subscribe((data) => {
      console.log(data)

      this.us.loginStatus();
      if (data != null) {
        var user = data;
        localStorage.setItem("user", JSON.stringify(user));
        this.us.loginStatus().subscribe();
        this.str = JSON.parse(JSON.stringify(user));
        this.role = this.str.role;
        this.username = this.str.username;
        localStorage.setItem("username", this.username);
        localStorage.setItem("role",this.role);
       
        if (this.role == "admin") {
          this.router.navigate(['/add-flight']);
        }
        else {
          this.router.navigate(['/home']);
        }

      }
      else {
        localStorage.setItem("user", 'null');
        localStorage.setItem("username", 'null');
        localStorage.setItem("role", 'null');
      }
    });
  }
}
