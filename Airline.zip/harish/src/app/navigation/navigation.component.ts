import { Component, DoCheck, OnInit, SimpleChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { iif } from 'rxjs';
import { UserService } from '../user.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
  validate: any;
  UserName: any;
  role: any;
  hide: any;
  status: string = "login";

  constructor(private us: UserService, private ar: ActivatedRoute, private router: Router) { }
  ngOnChanges(changes: SimpleChanges): void {
    throw new Error('Method not implemented.');
  }
  ngDoCheck(): void {
    this.us.loginStatus().subscribe((data) => {
      if (data == null) {
        this.status = "login";
      }
      else {
        this.status = "logout";
        this.UserName = localStorage.getItem("username");
      }
    });
    if (localStorage.getItem("user") == null) {
      this.validate = true;
    }
    else {
      this.validate = false;
    }

  }
  ngOnInit(): void {

  }
}
